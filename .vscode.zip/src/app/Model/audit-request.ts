export interface AuditRequest {
  projectName: string;
  projectOwnerName: string;
  applicationOwnerName: string;
  auditDetail: AuditDetail;
}

export interface Question {
  Question1: boolean;
  Question2: boolean;
  Question3: boolean;
  Question4: boolean;
  Question5: boolean;
}

export interface AuditDetail {
  type: string;
  date: string;
  questions: Question;
}
