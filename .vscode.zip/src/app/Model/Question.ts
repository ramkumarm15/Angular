export interface Question {
  question: string;
  questionNo: number;
}
