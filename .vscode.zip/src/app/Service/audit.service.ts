import * as http from '@angular/common/http';
import * as core from '@angular/core';

@core.Injectable({
  providedIn: 'root'
})
export class AuditService {

  url:string = "https://localhost:44309/api/AuditChecklist";

  constructor(private http:http.HttpClient) { }

  getAuditTypeQuestions(auditType:string){
    return this.http.get(`${this.url}/${auditType}`);
  }

}
