import * as http from '@angular/common/http';
import * as core from '@angular/core';
import * as router from '@angular/router';
import * as rxjs from 'rxjs';
import * as environment from 'src/environments/environment';
import * as login from '../Model/login';

@core.Injectable({
  providedIn: 'root',
})
export class AuthService {
  url: string = environment.environment.baseUrlAuth;
  isUserLoggedIn: boolean = false;
  constructor(private http: http.HttpClient, private route: router.Router) {}
  private handleError(error: http.HttpErrorResponse) {
    if (error.status === 0) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong.
      console.error(
        `Backend returned code ${error.status}, body was: `,
        error.error
      );
    }
    // Return an observable with a user-facing error message.
    return rxjs.throwError(
      () => new Error('Something bad happened; please try again later.')
    );
  }

  login(data: login.Login): rxjs.Observable<any> {
    return this.http.post(`${this.url}/Token`, data);
  }

  logout(): void {
    localStorage.removeItem('access_token');
    if (localStorage.getItem('access_token') == null)
      this.route.navigate(['login']);
  }

  getUserToken(): any {
    if (localStorage.getItem('access_token') != null) {
      return localStorage.getItem('access_token')?.toString();
    }
    return null;
  }

  verifyToken(): rxjs.Observable<any> {
    return this.http.get(`${this.url}/Token/Validate`);
  }

  getAllUsers(): rxjs.Observable<any> {
    return this.http.get(`${this.url}/Token`);
  }

  get isLoggedIn(): boolean {
    if (!this.isUserLoggedIn) {
      this.isUserLoggedIn =
        localStorage.getItem('access_token') != null ? true : false;
    }
    return this.isUserLoggedIn;
  }
}
