import * as core from '@angular/core';
import * as authService from 'src/app/Service/auth.service';

@core.Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements core.OnInit {
  constructor(private auth: authService.AuthService) {}

  ngOnInit(): void {}
  logout(): void {
    this.auth.logout();
  }

  getUsers(): void {
    this.auth.getAllUsers().subscribe((res) => console.log(res));
  }
}
