import * as core from '@angular/core';
import * as forms from '@angular/forms';
import * as router from '@angular/router';
import * as authService from 'src/app/Service/auth.service';

@core.Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements core.OnInit {
  constructor(
    private fb: forms.FormBuilder,
    private auth: authService.AuthService,
    private router: router.Router
  ) {}

  ngOnInit(): void {}

  notification = {
    showToast: false,
    errorMessage: '',
    type: 'info',
  };

  loginForm = this.fb.group({
    username: ['', [forms.Validators.required, forms.Validators.minLength(8)]],
    password: ['', [forms.Validators.required, forms.Validators.minLength(6)]],
  });

  addInfoToast(message: any, type: string) {
    this.notification.showToast = true;
    this.notification.errorMessage = message;
    this.notification.type = type;
    setTimeout(() => {
      this.notification.showToast = false;
      this.notification.errorMessage = '';
    }, 5000);
  }

  formSubmit() {
    this.auth.login(this.loginForm.value).subscribe({
      next: (data: any) => {
        console.log(data.status);
        localStorage.setItem('access_token', data.token);
        if (data.status == 200) this.router.navigate(['']);
      },
      error: (error: any) => {
        console.log(error);
        this.addInfoToast(error.error.message, 'danger');
        // console.error(error.error.);
      },
    });
  }

  states: any = [
    { name: 'Arizona', abbrev: 'AZ' },
    { name: 'California', abbrev: 'CA' },
    { name: 'Colorado', abbrev: 'CO' },
    { name: 'New York', abbrev: 'NY' },
    { name: 'Pennsylvania', abbrev: 'PA' },
  ];

  form = this.fb.group({
    state: this.fb.control(this.states[3].name),
  });

  submit(): void {
    console.log(this.form.value);
  }
}
