import { Component, OnInit } from '@angular/core';
import * as forms from '@angular/forms';
import { AuditDetail, AuditRequest } from 'src/app/Model/audit-request';
import { Question } from 'src/app/Model/Question';
import { AuditService } from 'src/app/Service/audit.service';

@Component({
  selector: 'app-audit-request',
  templateUrl: './audit-request.component.html',
  styleUrls: ['./audit-request.component.css'],
})
export class AuditRequestComponent implements OnInit {
  questions: Question[] = [];
  questionForm: forms.FormGroup = this.fb.group([]);

  auditRequestResult: AuditRequest = {} as AuditRequest;

  constructor(private audit: AuditService, private fb: forms.FormBuilder) {}

  auditTypeInput: any = [
    {
      name: 'Internal',
      value: 'Internal',
    },
    {
      name: 'SOX',
      value: 'SOX',
    },
  ];

  auditTypeForm = this.fb.group({
    auditType: ['', [forms.Validators.required]],
  });

  questionInput: any = [
    { name: 'question1', no: 1 },
    { name: 'question2', no: 2 },
    { name: 'question3', no: 3 },
    { name: 'question4', no: 4 },
    { name: 'question5', no: 5 },
  ];

  projectDetailsForm = this.fb.group({
    projectName: ['', forms.Validators.required],
    projectOwnerName: ['', forms.Validators.required],
    applicationOwnerName: ['', forms.Validators.required],
    date: ['', forms.Validators.required],
    questionform: this.fb.group([]),
  });

  ngOnInit(): void {
    console.log(this.auditRequestResult);
  }

  get questionFormArray() {
    return this.projectDetailsForm.get('questionform') as forms.FormGroup;
  }

  getAuditQuestions(type: string) {
    this.audit.getAuditTypeQuestions(type).subscribe({
      next: (res: any) => {
        console.log(res);
        this.questions = res;
        this.questions.forEach((x, i) =>
          this.questionFormArray.addControl(
            this.questionInput[i].name,
            this.fb.control(false)
          )
        );
      },
      error: (err) => {
        console.error(err);
      },
    });
  }

  formSubmit() {
    this.getAuditQuestions(this.auditTypeForm.controls['auditType'].value);
  }

  formValid() {
    let formData = this.projectDetailsForm.value;
    console.log(formData);

    this.auditRequestResult.applicationOwnerName =
      formData.applicationOwnerName;
    this.auditRequestResult.projectName = formData.projectName;
    this.auditRequestResult.projectOwnerName = formData.projectOwnerName;
    this.auditRequestResult.auditDetail.type =
      this.auditTypeForm.controls['auditType'].value;
    this.auditRequestResult.auditDetail.date = formData.date;
    this.auditRequestResult.auditDetail.questions.Question1 =
      formData.questionform.question1;
    this.auditRequestResult.auditDetail.questions.Question2 =
      formData.questionform.question2;
    this.auditRequestResult.auditDetail.questions.Question3 =
      formData.questionform.question3;
    this.auditRequestResult.auditDetail.questions.Question4 =
      formData.questionform.question4;
    this.auditRequestResult.auditDetail.questions.Question5 =
      formData.questionform.question5;
    console.log(this.auditRequestResult);
  }
}
